<template>
  <div>
          <h4>Comp1</h4>

    <div class="row">
      <div class="col">
          <h1>Camera</h1>
      </div>
    </div>
    <div class="row">
      <div class="col-4" v-for="i in 3" :key="i">
        <button class="my-button"><i class="far fa-lightbulb fa-2x"></i>
          <br />
          đèn {{i}}</button>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>
<style lang="scss" scoped>

  h4 {
      color: white;
  }
.col {
  width: 100%;
  height: 11.5rem;
  background-color: red;
  border-top-left-radius: 10px;
  border-top-right-radius: 10px;
}
.row {
  .col-4 {
    padding: 0.1rem;
    .my-button {
      width: 100%;
      height: 5.5rem;
      background-color: #6F7170;
      opacity: 0.8;
      color: whitesmoke;
      border-radius: 10px;
      &:focus {
        outline: none;
      }
      &:hover {
        opacity: 1;
        color: white;
      }
    }
  }
}
</style>