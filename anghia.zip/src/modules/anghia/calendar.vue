<template>
    <div class="cal-container text-center">
        calendar
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>
.cal-container {
    background: blue;
    color:white;
    height: 22rem;
}
</style>