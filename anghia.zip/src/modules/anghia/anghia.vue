<template>
  <div style="background: black">
    <div class="row">
      <div class="col-3">
        <div><clock></clock></div>
        <div><calendar></calendar></div>
      </div>
      <div class="col-9">
        <div class="row">
          <div class="col-8">
            <button class="btn btn-outline-secondary my-custom-button">
              <i class="fas fa-home"></i>Home
            </button>
            <button class="btn btn-outline-secondary my-custom-button">
              <i class="fas fa-home"></i>Home
            </button>
            <button class="btn btn-outline-secondary my-custom-button">
              <i class="fas fa-home"></i>Home
            </button>
            <button class="btn btn-outline-secondary my-custom-button">
              <i class="fas fa-home"></i>Home
            </button>
          </div>
          <div class="col-3 offset-1">
            <i class="fas fa-home my-custom-2-button fa-2x"></i>
            
            <i class="fas fa-home my-custom-2-button fa-2x"></i>
            <i class="fas fa-home my-custom-2-button fa-2x"></i>
          </div>
        </div>
        <div class="row">
          <div class="col-4">
            <comp1></comp1>
          </div>
          <div class="col-4">
            <comp2></comp2>
          </div>
          <div class="col-4">
            <comp3></comp3>
          </div>
        </div>
        <div class="row">
          <div class="col-4">
            <comp4></comp4>
          </div>
          <div class="col-4">
            <comp5></comp5>
          </div>
          <div class="col-4">
            <comp6></comp6>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import comp1 from "./comp1";
import comp2 from "./comp2";
import comp3 from "./comp3";
import comp4 from "./comp4";

import comp5 from "./comp5";

import comp6 from "./comp6";
import clock from "./clock";
import calendar from "./calendar"
export default {
  components: {
    comp1,
    comp2,
    comp3,
    comp4,
    comp5,
    comp6,
    clock,
    calendar
  }
};
</script>
<style lang="scss" scoped>
.row {
  .col-4 {
    padding-right: 2rem;
  }
}
.col-8 {
  padding-left: 0;
  .my-custom-button {
    margin-left: 0;
    margin-right: 0.5rem;
    color: white;
  }
}
.col-3 {
  .my-custom-2-button {
    margin-left: 1.5rem;
    float: right;
    color: white;
  }
}
i {
  cursor: pointer;
}
</style>