<template>
    <div class="clock-container text-center">
        Clock
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>
.clock-container {
    background: white;
    margin-top: 1rem;
    height: 22rem;
}
</style>