<template>
  <div>
            <h4>Comp1</h4>

    <div class="row">
      <div class="col-4" v-for="i in 9" :key="i">
        <button class="my-button">
          <i class="far fa-lightbulb fa-2x"></i>
          <br />
          đèn {{i}}
        </button>
      </div>
    </div>
  </div>
</template>
<script>
export default {};
</script>
<style lang="scss" scoped>

  h4 {
      color: white;
  }
.row {
  .col-4 {
    padding: 0.1rem;
    .my-button {
      width: 100%;
      height: 5.5rem;
      background-color: #6F7170;
      opacity: 0.8;
      color: whitesmoke;
      border-radius: 10px;
      &:focus {
        outline: none;
      }
      &:hover {
        opacity: 1;
        color: white;
      }
    }
  }
}
</style>