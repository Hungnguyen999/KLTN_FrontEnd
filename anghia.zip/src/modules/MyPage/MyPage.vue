<template>
    <div>
        my page
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="scss" scoped>

</style>