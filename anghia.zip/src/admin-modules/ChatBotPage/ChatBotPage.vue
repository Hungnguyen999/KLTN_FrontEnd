<template>
    <div>ChatBot Page</div>
</template>