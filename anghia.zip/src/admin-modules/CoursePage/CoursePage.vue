<template>
    <div>Course Page</div>
</template>