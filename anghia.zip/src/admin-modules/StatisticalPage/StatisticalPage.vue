<template>
    <div>Statistical Page</div>
</template>